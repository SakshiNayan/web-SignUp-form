import React from 'react'
import App from './App'

function UserPg(props) {
  return (
    <div>
      <h1>Hello {this.props.userName}</h1>
    </div>
  )
}

export default UserPg
